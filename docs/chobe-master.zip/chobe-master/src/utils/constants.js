export const newsType = {
  hyxw: 1,
  IPO: 2,
  ssxw: 3,
  qbdt: 4,
  gzh: 5
}
export const intlType = {
  cn: 1,
  en: 2,
}